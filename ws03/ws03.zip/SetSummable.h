#ifndef SDDS_SETSUMMABLE_H
#define SDDS_SETSUMMABLE_H
#include "Set.h"
namespace sdds {
	template<typename T, unsigned int N>
	class SetSummable : public Set<T, N>{
	public:
		SetSummable() {}
		T accumulate(const std::string& filter) const;
	};

	




	template<typename T, unsigned int N>
	inline T SetSummable<T, N>::accumulate(const std::string& filter) const
	{
		T localt(filter);
		for (unsigned int i = 0; i < (*this).size(); i++) {
			localt += (*this).operator[](i);	//important note	
		}

		return localt;

	}

}

#endif
