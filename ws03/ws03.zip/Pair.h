#ifndef SDDS_PAIR_H
#define SDDS_PAIR_H
#include <string>
#include <iostream>
#include <iomanip>
namespace sdds {
	
	template<typename K, typename V>
	class Pair {
		K pkey;
		V pvalue;

	public:
		Pair(K sp) { pkey = sp; }

		Pair(const K& cpyKey, const V& cpyValue) {
				pkey = cpyKey;
				pvalue = cpyValue;
		}

		const K& key() const { 
			return pkey; }

		const V& value() const { 

			return pvalue; }

		virtual void display(std::ostream& os) const;



	//	Pair(std::string str, int num);

		

	};
	template<typename K, typename V>
	std::ostream& operator<<(std::ostream& os, const Pair<K, V>& pair) {
		pair.display(os);
		return os;
	}
	template<typename K, typename V>
	void Pair<typename K, typename V>::display(std::ostream& os) const {
		//	std::cout << "display called" << "\n";
		os << pkey << " : " << pvalue << std::endl;
	}

	/*
	template<typename K, typename V>
	Pair<K,V>::Pair(std::string str, int num) {
		pkey = str;
		pvalue = num;

	}

	*/
	
	








}




#endif