/*
#ifndef SDDS_SET_H
#define SDDS_SET_H
namespace sdds {
template<typename T, unsigned int N>
class Set {
	T collection[N]{};
	unsigned int numOfcollection = 0;
public:
	Set();
	size_t size() const {
		return numOfcollection;
	}
	Set<const char*, unsigned int>(const char* str, unsigned int num=1) {
		string  collection[num] = str;
		numOfcollection = num;
	}

	const T& operator[](size_t idx) const {
		if (idx >= 0 && static_cast<unsigned int>(idx) < numOfcollection) {
		//	std::cout << "operator [] called" << "\n";
			return collection[idx];
		}
	}

	void operator+=(const T& item) {
		if (numOfcollection < (N)) {
		//	std::cout << "operator += called" << "\n";
			collection[numOfcollection] = item;
			++numOfcollection;
		}
	}
	
	unsigned int get_numOfcollection() const {
		return numOfcollection;
	}



};


template<typename T, unsigned int N>
 inline Set<T, N>::Set()
{
	// std::cout << "set constructor called" << "\n";
	numOfcollection = 0;
}

}
#endif

*/

#ifndef SDDS_SET_H
#define SDDS_SET_H
#include <string>
#include <iostream>
#include <iomanip>
namespace sdds {
	template<typename T, unsigned int N>
	class Set {
		T collection[N]{};
		unsigned int numOfcollection = 0;
	public:
		Set();
	




		size_t size() const {
			return numOfcollection;
		}



		const T& operator[](size_t idx) const {
			if (idx >= 0 && static_cast<unsigned int>(idx) < numOfcollection) {
				//	std::cout << "operator [] called" << "\n";
				return collection[idx];
			}
		}

		void operator+=(const T& item) {
			if (numOfcollection < (N)) {
				//	std::cout << "operator += called" << "\n";
				collection[numOfcollection] = item;
				++numOfcollection;
			}
		}


	};


	template<typename T, unsigned int N>
	 Set<T, N>::Set()
	{
		// std::cout << "set constructor called" << "\n";
		numOfcollection = 0;
	}

}
#endif