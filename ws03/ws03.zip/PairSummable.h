#ifndef SDDS_PAIRSUMMABLE_H
#define SDDS_PAIRSUMMABLE_H
#include <iomanip>
#include "Pair.h"
namespace sdds {
     template<typename K, typename V>
     class PairSummable : public Pair< K, V>
     {
         static  V initialValue;
         static  size_t width;


     public:
        // PairSummable() { width = 0; }
         PairSummable(K sps) :Pair(sps) { }

         PairSummable(const K& key, const V& value = initialValue) : Pair<K,V>(key, initialValue) {
             if (width < key.size()) {
                 width = key.size();
             }

         }

      

         PairSummable& operator+=(const PairSummable& cpy) {
             if (this != &cpy && this->key() == cpy.key()) {
                 *this = PairSummable(this->key(), this->value() + cpy.value());
             }
             return *this;
         }




         void display(std::ostream& os) const override {
             os << std::setw(width) << std::left;
             Pair< K, V>::display(os);
             os << std::left;
           
         }




       


     };

    
 
  

    template<>
    PairSummable<std::string, std::string>& PairSummable<std::string, std::string>:: operator += (const PairSummable& cpy) {
        if (this != &cpy && (*this).key() == cpy.key()) {

            initialValue = initialValue + ", " + cpy.value();
        }
        return *this;
    }


  
    template<>
    std::string PairSummable<std::string, std::string>::initialValue = "";

    template<>
    int PairSummable<std::string, int>::initialValue = 0;

    template<typename K, typename V>
      size_t PairSummable<K,V>::width = 0;





}
#endif
